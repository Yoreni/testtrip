function IScene()
{

}
//IScene.prototype = Object.create(PIXI.Container.prototype);

IScene.prototype.start = () => {}
IScene.prototype.stop = () => {}
IScene.prototype.update = (delta) => {}
IScene.prototype.destory = () => {}
IScene.prototype.init = () => {}